#include <QApplication>
#include "trafficlight.h"
#include "calculator.h"
#include "digitalclock.h"
#include "QDesktopWidget"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
     Calculator calc;
     calc.setWindowTitle("Calculator");
     calc.showMaximized();
     calc.setFixedSize(400,500);
     calc.move(QApplication::desktop()->screen()->rect().center()-calc.rect().center());

    //Creating the traffic light
   auto light = new TrafficLight;
    //showing the trafic light
   light->show();

    auto D = new DigitalClock;
    D->show();

    return a.exec();
}
