#ifndef DIGITALCLOCK_H
#define DIGITALCLOCK_H

#include <QWidget>
#include<QLCDNumber>
#include<QTimerEvent>

class DigitalClock : public QWidget
{

public:
    explicit DigitalClock(QWidget *parent = nullptr);

protected:
  void   createWidgets();
  void  placeWidgets();
  void updateTime();



protected:
  QLCDNumber *hour;
  QLCDNumber *second;
  QLCDNumber *minute;

  //surcherger
  void timerEvent(QTimerEvent *e) override;

};

#endif // DIGITALCLOCK_H
