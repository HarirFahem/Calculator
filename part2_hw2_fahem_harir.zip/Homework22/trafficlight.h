#ifndef TRAFFIC_LIGHT_H
#define TRAFFIC_LIGHT_H

#include <QWidget>
#include<QVector>
#include<QApplication>
#include<QKeyEvent>

class QRadioButton;

class TrafficLight: public QWidget{
  Q_OBJECT

public:

  TrafficLight(QWidget * parent = nullptr);

  void timerEvent(QTimerEvent *e) override;
  void keyPressEvent(QKeyEvent *e)override;
protected:
     void createWidgets();
     void placeWidgets();


private:

  QRadioButton * redlight;
  QRadioButton * yellowlight;
  QRadioButton * greenlight;
  //QVector<QRadioButton*> lights ;
  int times[3] = {4,1,2};
  int index;
  int currentTime;



};


#endif
