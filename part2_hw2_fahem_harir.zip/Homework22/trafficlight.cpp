#include "trafficlight.h"
#include <QWidget>
#include <QLayout>
#include <QRadioButton>

TrafficLight::TrafficLight(QWidget * parent): QWidget(parent){

    //Creatign the widgets
    createWidgets();

    //place Widgets
    placeWidgets();
}

void TrafficLight::createWidgets()
{

  redlight = new QRadioButton;
  redlight->setEnabled(false);
  redlight->toggle();
  redlight->setStyleSheet("QRadioButton::indicator:checked { background-color: red;}");

  yellowlight = new QRadioButton;
  yellowlight->setEnabled(false);

  yellowlight->setStyleSheet("QRadioButton::indicator:checked { background-color: yellow;}");
  yellowlight->setChecked(false);

  greenlight = new QRadioButton;
  greenlight->setEnabled(false);
  greenlight->setStyleSheet("QRadioButton::indicator:checked { background-color: green;}");

  //lights.append(redlight);
  //lights.append(yellowlight);
  //lights.append(greenlight);

  //index=0;

 // startTimer(2000);
  currentTime=0;
}


void TrafficLight::placeWidgets()
{

  // Placing the widgets
  auto layout = new QVBoxLayout;
  layout->addWidget(redlight);
  layout->addWidget(yellowlight);
  layout->addWidget(greenlight);
  setLayout(layout);
}


void TrafficLight::timerEvent(QTimerEvent *e){

    currentTime++;
    if(redlight->isChecked()&& currentTime==4){

        yellowlight->toggle();
        currentTime=0;
    }
    if(yellowlight->isChecked()&& currentTime ==1){
        greenlight->toggle();
        currentTime=0;
    }
    if(greenlight->isChecked()&& currentTime ==2){
        redlight->toggle();
        currentTime=0;
    }
//index = (index + 1) % 3 ;

//lights[index]->toggle();

}
void TrafficLight::keyPressEvent(QKeyEvent *e){
    //si je clique sur echap je quitte

    if(e->key() == Qt::Key_Escape)
        qApp->exit();
    if(e->key() == Qt::Key_R)
           {
        index=0;
        redlight->toggle();
    }
    if(e->key() == Qt::Key_Y)
           {
        index=1;
        yellowlight->toggle();
    }
    if(e->key() == Qt::Key_G)
           {
        index=2;
        greenlight->toggle();
    }


}

