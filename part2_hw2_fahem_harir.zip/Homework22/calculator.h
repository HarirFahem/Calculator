#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <QWidget>
#include<QGridLayout>
#include<QVector>
#include<QPushButton>
#include<QLCDNumber>



class Calculator : public QWidget
{
    Q_OBJECT

public:
    Calculator(QWidget *parent = nullptr);
    ~Calculator();


protected:
    void createWidgets();
    void placeWidgets();
    void makeConnexions();

public slots:
  void newDigit();
  void changeOperation();
  void Clear();
  void ShowResult();
  void ShowResult1();
  void Ln();





  private:

      QGridLayout *buttonsL;
      QVBoxLayout *Layout;
      QVector<QPushButton*> digits;
      QPushButton *clear;
      QPushButton *Close;
      QVector<QPushButton*> operations;
      QVector<QPushButton*> operations1;
      QLCDNumber *disp;
      QPushButton *point;
      QPushButton *result;
      double * left=nullptr;
      double * right=nullptr;
      QString *operation=nullptr;







};

#endif // CALCUL_H
