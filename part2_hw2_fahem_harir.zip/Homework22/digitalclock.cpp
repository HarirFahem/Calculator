#include "digitalclock.h"
#include<QTime>
#include<QHBoxLayout>

DigitalClock::DigitalClock(QWidget *parent) : QWidget(parent)
{
createWidgets();

placeWidgets();
setWindowTitle("Digital Clock");
startTimer(1000);
}
void DigitalClock::updateTime(){
    //mettre le temp
    auto T =QTime::currentTime();
    hour->display(T.hour());
    minute->display(T.minute());
    second->display(T.second());



}

void DigitalClock::createWidgets(){
    hour = new QLCDNumber;
    minute = new QLCDNumber;
    second = new QLCDNumber;

   // mettre le temp
    auto T =QTime::currentTime();
    hour->display(T.hour());
    minute->display(T.minute());
    second->display(T.second());

}

void DigitalClock::placeWidgets(){

   hour->setMinimumHeight(100);
   minute->setMinimumHeight(100);
   second->setMinimumHeight(100);
 QLayout * layout = new QHBoxLayout;
 setLayout(layout);
 layout->addWidget(hour);
 layout->addWidget(minute);
 layout->addWidget(second);


}


void DigitalClock::timerEvent(QTimerEvent *e){
    auto T =QTime::currentTime();
    hour->display(T.hour());
    minute->display(T.minute());
    second->display(T.second());

}
